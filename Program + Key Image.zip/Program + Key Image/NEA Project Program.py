import pygame, random
from random import shuffle
def main():
    pygame.init()
    #Sets the borders of the game's window and loads the image used to represent keys into memory.
    screen_x = 700
    screen_y = 500
    screen = pygame.display.set_mode([screen_x, screen_y])
    #Constants which are used to set the colour of the objects on screen.
    WHITE = (255, 255, 255)
    BLACK = (0, 0, 0)
    W_BLUE = (92, 112, 247)
    I_BLUE = (0, 205, 255)
    RED = (255, 0, 0)
    GREEN = (2, 217, 2)
    YELLOW = (255, 222, 0)
    PURPLE = (162, 0, 255)
    try:
        gamekey = pygame.image.load("key.png").convert()
        gamekey.set_colorkey(WHITE)
        key_loaded = True
    except:
        key_loaded = False
    pygame.display.set_caption("Introduction to Forces")
    
    class Player():
        def __init__(self):
            self.x = 25
            self.y = 25
            self.centre = 25
            self.colour = (70, 3, 255)
            self.radius = 25
            self.hitbox = 12.5
            self.keyhold = False
            self.ychange = 0.0
            self.jump = True
            self.racc = 0.0
            self.lacc = 0.0
            self.ridle = 0.0
            self.lidle = 0.0
            self.rm = 1
            self.lm = 1
            self.f = 0.0
            self.bm = 1
            self.wr = 1
            self.room = "title"
    
        def calcXSpeed(self, xchange):
            self.x = self.x + xchange
            pygame.display.flip()
        
        def calcYSpeed(self, ychange):
            self.y = self.y + (player.ychange / player.bm)
            pygame.display.flip()

    player = Player()
    
    class Terrain():
        def __init__(self, x, y, width, height, colour, up_semi, down_semi, right_semi, left_semi, friction):
            self.x = x
            self.y = y
            self.w = width
            self.h = height
            self.c = colour
            self.us = up_semi
            self.ds = down_semi
            self.rs = right_semi
            self.ls = left_semi
            self.f = friction
            self.ids = False
            self.ground = False
            self.active = True
        
        def TerrainCollision(self):
            #Checks whether the player is close to the terrain.
            if (self.x - player.radius <= player.x <= self.x + self.w + player.radius and self.y - player.radius <= player.y <= self.y + self.h + player.radius) and self.active == True:
                self.ground = True
                #Handles collisions between the top of the terrain and the player.
                if player.ychange >= 0.0 and self.ds == False and player.y < self.y:
                    if self.x - player.hitbox <= player.x <= self.x + self.w + player.hitbox:
                        player.y = self.y - player.radius
                        player.f = self.f
                        player.jump = True
                        player.lm = 1
                        player.rm = 1
                        player.ychange = 0.0
                    else:
                        #Changes where the player will start falling when moving off of terrain depending on how quickly they are accelerating.
                        if (player.racc > 3 and player.x > self.x + self.w) or (player.lacc < -3 and player.x < self.x):
                                player.jump = False
                                self.ground = False
                #Handles collisions between the bottom of a block of terrain and the player.
                elif player.ychange < 0 and player.y > self.y + self.h and self.us == False:
                    player.y = self.y + self.h + player.radius
                    player.ychange = 0.0
                #Handles collisions between the left side of a block of terrain and the player.
                elif player.racc > 0 and player.x < self.x + self.w and self.y < player.y < self.y + self.h and self.rs == False and ((right == True or player.jump == False) or self.ids == False):
                    player.x = self.x - player.radius
                    player.racc = 0.0
                    player.ridle = 0.0
                    if player.jump == False:
                        self.ground = False
                #Handles collisions between the right side of a block of terrain and the player.
                elif player.lacc < 0 and self.x < player.x and self.y < player.y < self.y + self.h and self.ls == False:
                    player.x = self.x + self.w + player.radius
                    player.lacc = 0.0
                    player.lidle = 0.0
                    if player.jump == False:
                        self.ground = False
                #Makes the player fall through the top side of a terrain block if its collision algorithm isn't active.
                if self.ds == True and (self.x + player.radius <= player.x < self.x + self.w - player.radius or (player.lacc < -3 and player.x < self.x + self.w) or (player.racc > 3 and player.x > self.x)):
                    player.jump = False
                    self.ground = False
            else:
                self.ground = False
            
            
        def Redefine(self, x, y, w, h, c, us, ds, rs, ls, f):
            self.x = x
            self.y = y
            self.w = w
            self.h = h
            self.c = c
            self.us = us
            self.ds = ds
            self.rs = rs
            self.ls = ls
            self.f = f
          
                
    class Ramp():
        def __init__(self, x1, y1, x2, y2, x3, y3, colour, gradient, yintercept, direction_of_incline, left_modifier, right_modifier, next_to_ground_right, next_to_ground_left, boundary):
            self.x1 = x1
            self.y1 = y1
            self.x2 = x2
            self.y2 = y2
            self.x3 = x3
            self.y3 = y3
            self.c = colour
            self.g = gradient
            self.yi = yintercept
            self.doi = direction_of_incline
            self.lm = left_modifier
            self.rm = right_modifier
            self.rntg = next_to_ground_right
            self.lntg = next_to_ground_left
            self.b = boundary
            self.ground = False
            self.active = True
            
        def RampCollision(self):
            if self.doi == "Left" and self.active == True:
                #Checks whether the player is close to the ramp.
                if (self.x1 + self.b - player.radius <= player.x <= self.x3 + player.radius - self.b and self.y1 - player.radius <= player.y <= self.y3 + player.radius):
                    self.ground = True
                    #Checks whether the player is colliding with the bottom of the ramp.
                    if player.ychange < 0.0 and player.y > self.y3:
                        player.y = self.y3 + player.radius
                        player.ychange = 0.0
                    #Checks whether the player is colliding with the ramp's hypoteneuse while falling.
                    if player.ychange > 0 and player.y < self.y3 and player.y > ((player.x * self.g) + self.yi) - (player.radius):
                        if player.x > self.x1 + self.b:
                            player.y = ((player.x * self.g) + self.yi) - (player.radius + (self.g // 1) * 10)
                            player.jump = True
                            player.ychange = 0.0
                            player.lm = self.lm
                            player.rm = self.rm 
                        elif player.x < self.x1 + self.b:
                            if self.lntg == True:
                                player.y = self.y1 - player.radius
                                player.jump = True
                                player.lm = 1
                                player.rm = 1
                                player.ychange = 0.0
                            else:
                                player.y = ((player.x * self.g) + self.yi) - (player.radius + (self.g // 1) * 10)
                                player.jump = True
                                player.lm = self.lm
                                player.rm = self.rm
                                player.ychange = 0.0
                    #Checks whether the player is colliding with the ramp's hypoteneuse while on the ground.
                    if player.ychange == 0 and player.jump == True and player.y != ((player.x * self.g) + self.yi) - (player.radius + (self.g // 1) * 10):
                        if player.x > self.x1 + self.b:
                            player.y = ((player.x * self.g) + self.yi) - (player.radius + (self.g // 1) * 10)
                            player.jump = True
                            player.lm = self.lm
                            player.rm = self.rm
                            player.ychange = 0.0
                        elif player.x < self.x1 + self.b:
                            if self.lntg == True:
                                player.y = self.y1 - player.radius
                                player.jump = True
                                player.lm = 1
                                player.rm = 1
                                player.ychange = 0.0
                            else:
                                player.y = ((player.x * self.g) + self.yi) - (player.radius + (self.g // 1) * 10)
                                player.jump = True
                                player.lm = self.lm
                                player.rm = self.rm
                                player.ychange = 0.0
                        if player.x > self.x3 - self.b:
                            if self.rntg == True:
                                player.y = self.y3 - player.radius
                                player.jump = True
                                player.lm = 1
                                player.rm = 1
                                player.ychange = 0.0
                            else:
                                player.y = ((player.x * self.g) + self.yi) - (player.radius + (self.g // 1) * 10)
                                player.jump = True
                                player.lm = self.lm
                                player.rm = self.rm
                                player.ychange = 0.0
                    #Checks whether the player is colliding with the side of the corner of the ramp. 
                    if self.y3 - 17 <= player.y <= self.y3 + 17 and player.x > self.x3 + player.hitbox:
                        player.x = self.x3 + player.radius
                        player.lacc = 0.0
                        player.lidle = 0.0           
                else:
                    self.ground = False
                    
            if self.doi == "Right" and self.active == True:
                #Checks whether the player is close to the ramp.
                if (self.x1 - player.radius <= player.x <= self.x3 + player.radius and self.y3 - player.radius <= player.y <= self.y1 + player.radius):
                    self.ground = True
                    #Checks whether the player is colliding with the bottom of the ramp.
                    if player.ychange < 0.0 and player.y > self.y1:
                        player.y = self.y1 + player.radius
                        player.ychange = 0.0
                    #Checks whether the player is colliding with the ramp's hypoteneuse while falling.
                    if player.ychange > 0 and player.y < self.y1 and player.y > ((player.x * self.g) + self.yi) - (player.radius):
                        if player.x > self.x1 + self.b:
                            player.y = ((player.x * self.g) + self.yi) - (player.radius + (self.g // 1) * 10)
                            player.jump = True
                            player.ychange = 0.0
                            player.lm = self.lm
                            player.rm = self.rm
                    #Checks whether the player is colliding with the ramp's hypoteneuse while on the ground.
                    if player.ychange == 0 and player.jump == True and player.y != ((player.x * self.g) + self.yi) - (player.radius + (self.g // 1) * 10):
                        if player.x < self.x3 - self.b:
                            player.y = ((player.x * self.g) + self.yi) - (player.radius + (self.g // 1) * 10)
                            player.jump = True
                            player.lm = self.lm
                            player.rm = self.rm
                            player.ychange = 0.0
                        elif player.x > self.x3 - self.b:
                            if self.rntg == True:
                                player.jump = True
                                player.lm = 1
                                player.rm = 1
                                player.ychange = 0.0
                            else:
                                player.jump = True
                                player.lm = self.lm
                                player.rm = self.rm
                                player.ychange = 0.0
                        if player.x < self.x1 + self.b:
                            if self.lntg == True:
                                player.y = self.y1 - player.radius
                                player.jump = True
                                player.lm = 1
                                player.rm = 1
                                player.ychange = 0.0
                            else:
                                player.y = ((player.x * self.g) + self.yi) - (player.radius + (self.g // 1) * 10)
                                player.jump = True
                                player.lm = self.lm
                                player.rm = self.rm
                                player.ychange = 0.0
                    #Checks whether the player is colliding with the side of the corner of the ramp.
                    if self.y1 - 17 <= player.y <= self.y1 + 17 and player.x < self.x1 - player.hitbox:
                        player.x = self.x1 - player.radius
                        player.racc = 0.0
                        player.ridle = 0.0
                else:
                    self.ground = False
                  
        def Redefine(self, x1, y1, x2, y2, x3, y3, c, g, yi, doi, lm, rm, rntg, lntg, s):
            self.x1 = x1
            self.y1 = y1
            self.x2 = x2
            self.y2 = y2
            self.x3 = x3
            self.y3 = y3 
            self.c = c
            self.g = g
            self.yi = yi
            self.doi = doi
            self.lm = lm
            self.rm = rm
            self.rntg = rntg
            self.lntg = lntg
            self.s = s
            
                    
    class Hazard():
        def __init__(self, x, y, width, height, direction, speed, end_x_point, end_y_point):
            self.x = x
            self.y = y
            self.w = width
            self.h = height
            self.c_d = direction
            self.i_d = direction
            self.sp = speed
            self.sxp = x
            self.syp = y
            self.exp = end_x_point
            self.eyp = end_y_point
            self.colour = YELLOW
            self.active = True

        def HazardMove(self, movement):
            if self.c_d == "Right":
                self.x = self.x + movement
                pygame.display.flip()
            elif self.c_d == "Left":
                self.x = self.x - movement
                pygame.display.flip()
            elif self.c_d == "Up":
                self.y = self.y - movement
                pygame.display.flip()
            elif self.c_d == "Down":
                self.y = self.y + movement
                pygame.display.flip()
                
                
        def BoundaryCheck(self):
            if self.i_d == "Up":
                if self.y <= self.eyp:
                    self.c_d = "Down"
                if self.c_d == "Down" and self.y >= self.syp:
                    self.c_d = self.i_d
            if self.i_d == "Down":
                if self.y >= self.eyp:
                    self.c_d = "Up"
                if self.c_d == "Up" and self.y <= self.syp:
                    self.c_d = self.i_d
            if self.i_d == "Right":
                if self.x >= self.exp:
                    self.c_d = "Left"
                if self.c_d == "Left" and self.x <= self.sxp:
                    self.c_d = self.i_d
            if self.i_d == "Left":
                if self.x <= self.exp:
                    self.c_d = "Right"
                if self.c_d == "Right" and self.x >= self.sxp:
                    self.c_d = self.i_d
                
        def HazardCollision(self):
            if self.x - player.radius <= player.x <= self.x + self.w + player.radius and self.y - player.radius <= player.y <= self.y + self.h + player.radius and self.active == True:
                player.x = xspawn
                player.y = yspawn
                player.racc = 0
                player.lacc = 0
                player.ridle = 0
                player.lidle = 0
                player.ychange = 0.0                  
        
        def Redefine(self, x, y, w, h, i_d, exp, eyp):
            self.x = x
            self.y = y
            self.w = w
            self.h = h
            self.i_d = i_d
            self.c_d = i_d
            self.sxp = x
            self.syp = y
            self.exp = exp
            self.eyp = eyp
            
    class Lock():
        def __init__(self, x, y, width, height):
            self.x = x
            self.y = y
            self.w = width
            self.h = height
            self.colour = PURPLE
            self.locked = True
            self.active = True
            
        def LockCollision(self):
            if self.locked == True and self.active == True and self.x - player.radius <= player.x <= self.x + self.w + player.radius and self.y - player.radius <= player.y <= self.y + self.h + player.radius:
                #Handles collisions on the left side of the locked barrier.
                if player.racc > 0 and player.x < self.x + self.w and self.y < player.y < self.y + self.h:
                    if player.keyhold == True:
                        self.locked = False
                        player.keyhold = False
                    else:
                        player.x = self.x - player.radius
                        player.racc = 0.0
                        player.ridle = 0.0
                #Handles collisions on the right side of the locked barrier.
                elif player.lacc < 0 and self.x < player.x and self.y < player.y < self.y + self.h:
                    if player.keyhold == True:
                        self.locked = False
                        player.keyhold = False
                    else:
                        player.x = self.x + self.w + player.radius
                        player.lacc = 0.0
                        player.lidle = 0.0
                                
        def Redefine(self, x, y, width, height):
            self.x = x
            self.y = y
            self.w = width
            self.h = height
    
    if key_loaded == True:
        class Key():
            def __init__(self, x, y):
                self.x = x
                self.y = y
                self.w = 100
                self.h = 56
                self.image = gamekey
                self.active = True
                self.used = False
            
            def Pickup(self):
                if self.x - player.hitbox <= player.x <= self.x + self.w + player.hitbox and self.y - player.hitbox <= player.y <= self.y + self.h + player.hitbox and self.active == True:
                    player.keyhold = True
                    self.used = True
                    
            def Redefine(self, x, y):
                self.x = x
                self.y = y
    else:
        class Key():
            def __init__(self, x, y):
                self.x = x
                self.y = y
                self.w = 100
                self.h = 56
                self.colour = PURPLE
                self.active = True
                self.used = False
            
            def Pickup(self):
                if self.x - player.hitbox <= player.x <= self.x + self.w + player.hitbox and self.y - player.hitbox <= player.y <= self.y + self.h + player.hitbox and self.active == True:
                    player.keyhold = True
                    self.used = True
                    
            def Redefine(self, x, y):
                self.x = x
                self.y = y
            
    class Water():
        def __init__(self, x, y, width, height):
            self.x = x
            self.y = y
            self.w = width
            self.h = height
            self.active = True
            
        def WaterCollision(self):
            if self.active == True and self.x - player.radius <= player.x <= self.x + self.w + player.radius and self.y - player.radius <= player.y <= self.y + self.h + player.radius:
                if player.bm == 1:
                    c = 0
                    while c < 5:
                        player.ychange = player.ychange - (player.ychange * 0.05)
                        c = c + 1
                player.bm = 2.5
                player.wr = 0.375
            else:
                if player.bm == 2.5:
                    player.ychange = player.ychange / 2.5
                    player.bm = 1
                    player.wr = 1
                
        def Redefine(self, x, y, w, h):
            self.x = x
            self.y = y
            self.w = w
            self.h = h
    
            
    class Textbox():
        def __init__(self, text, antialias, colour, x, y, fontname, size, bold, italics):
            self.t = text
            self.aa = antialias
            self.c = colour
            self.x = x
            self.y = y
            self.f = fontname
            self.s = size
            self.b = bold
            self.i = italics
            self.font = ""
            self.box = ""         
        
        def Write(self):
            self.font = pygame.font.SysFont(self.f, self.s, self.b, self.i)
            self.box = self.font.render(f"{self.t}", self.aa, self.c)
            screen.blit(self.box, [self.x, self.y])
        
        def Redefine(self, text, antialias, colour, x, y, fontname, size, bold, italics):
            self.t = text
            self.aa = antialias
            self.c = colour
            self.x = x
            self.y = y
            self.f = fontname
            self.s = size
            self.b = bold
            self.i = italics
            
    ground1 = Terrain(0, 200, 700, 100, BLACK, False, False, False, False, 0.25)
    ground2 = Terrain(0, 450, 215, 50, BLACK, False, False, False, False, 0.25)
    ground3 = Terrain(315, 450, 185, 100, BLACK, False, False, False, False, 0.25)
    ground4 = Terrain(215, 450, 100, 10, RED, True, False, False, False, 0.25)
    ground5 = Terrain(600, 100, 100, 5, BLACK, False, False, False, False, 0.25)
    ground6 = Terrain(0, 125, 50, 175, BLACK, False, False, False, False, 0.25)
    ground7 = Terrain(0, -25, 215, 50, BLACK, False, False, False, False, 0.25)
    ground8 = Terrain(310, -25, 5, 50, RED, False, False, False, True, 0.25)
    ramp1 = Ramp(630, 450, 630, 500, 677.5, 500, BLACK, 20/19, -213.1578947, "Left", 0.0, 2.0, False, True, 10)
    ramp2 = Ramp(100, 100, 100, 100, 0, 0, BLACK, 0, 0, "Left", 0, 0, True, False, 0)
    ramp3 = Ramp(100, 100, 100, 100, 0, 0,  BLACK, 0, 0, "Left", 0, 0, False, True, 10)
    water = Water(100, 400, 200, 100)
    key1 = Key(0, 394)
    key2 = Key(600, 100)
    lock1 = Lock(390, 200, 30, 200)
    lock2 = Lock(0, 350, 50, 100)
    hazard1 = Hazard(150, 362.5, 37.5, 37.5, "Right", 1, 500, 362.5)
    hazard2 = Hazard(100, 350, 0, 0, "Up", 1, 0, 0)
    textbox1 = Textbox("", True, BLACK, 0, 0, "Calibri", 25, False, False)
    textbox2 = Textbox("", True, BLACK, 0, 0, "Calibri", 25, False, False)
    textbox3 = Textbox("", True, BLACK, 0, 0, "Calibri", 25, False, False)
    textbox4 = Textbox("", True, BLACK, 0, 0, "Calibri", 25, False, False)
    textbox5 = Textbox("", True, BLACK, 0, 0, "Calibri", 25, False, False)
    textbox6 = Textbox("", True, BLACK, 0, 0, "Calibri", 25, False, False)
    textbox7 = Textbox("", True, BLACK, 0, 0, "Calibri", 25, False, False)
    textbox8 = Textbox("", True, BLACK, 0, 0, "Calibri", 25, False, False)
    textbox9 = Textbox("", True, BLACK, 0, 0, "Calibri", 25, False, False)
    textbox10 = Textbox("", True, BLACK, 0, 0, "Calibri", 25, False, False)
    textbox11 = Textbox("", True, BLACK, 0, 0, "Calibri", 25, False, False)
    textbox12 = Textbox("", True, BLACK, 0, 0, "Calibri", 25, False, False)
    textbox13 = Textbox("", True, BLACK, 0, 0, "Calibri", 25, False, False)
    textbox14 = Textbox("", True, BLACK, 0, 0, "Calibri", 25, False, False)

    def room1():
        #Subroutine which draws room 1 when called.
        ground1.Redefine(0, 200, 700, 100, BLACK, False, False, False, False, 0.25)
        ground2.Redefine(0, 450, 215, 50, BLACK, False, False, False, False, 0.25)
        ground3.Redefine(215, 450, 100, 10, RED, True, False, True, True, 0.25)
        ground4.Redefine(315, 450, 385, 100, BLACK, False, False, False, False, 0.25)
        water.active = False
        ground1.active = True
        ground2.active = True
        ground3.active = True
        ground4.active = True
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        lock1.active = False
        lock2.active = False
        ramp1.active = False
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = False
        hazard1.active = False
        hazard2.active = False
        textbox1.Redefine("Press A or the Left Arrow key to move left.", True, BLACK, 145, 50, "Calibri", 25, False, False)
        textbox2.Redefine("Press D or the Right Arrow key to move right.", True, BLACK, 130, 100, "Calibri", 25, False, False)
        textbox3.Redefine("Friction is a force which acts upon two surfaces when they slide over each other, causing the ones in motion to", True, BLACK, 15, 320, "Calibri", 15, False, False)
        textbox4.Redefine("slow down.", True, BLACK, 15, 345, "Calibri", 15, False, False)
        textbox5.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox6.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox7.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox8.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox9.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "1"
        
        
    def room2():
        #Subroutine which draws room 2 when called.
        ground1.Redefine(0, 200, 700, 100, BLACK, False, False, False, False, 0.25)
        ground2.Redefine(175, 150, 350, 50, BLACK, False, False, False, False, 0.25)
        water.active = False
        ground1.active = True
        ground2.active = True
        ground3.active = False
        ground4.active = False
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        ramp1.active = False
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = False
        hazard1.active = False
        hazard2.active = False
        lock1.active = False
        lock2.active = False
        textbox1.Redefine("Press the Space Bar to Jump.", True, BLACK, 205, 50, "Calibri", 25, False, False)
        textbox2.Redefine("The ball has no way to change its trajectory while midair,", True, BLACK, 120, 350, "Calibri", 20, False, False)
        textbox3.Redefine("so get a running start before jumping.", True, BLACK, 197, 370, "Calibri", 20, False, False)
        textbox4.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox5.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox6.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox7.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox8.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox9.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "2"
        
    def room3():
        #Subroutine which draws room 3 when called.
        ground1.Redefine(0, 200, 360, 300, BLACK, False, False, False, False, 0.25)
        ground2.Redefine(540, 0, 160, 500, BLACK, False, False, False, False, 0.25)
        water.active = False
        ground1.active = True
        ground2.active = True
        ground3.active = False
        ground4.active = False
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        ramp1.active = False
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = False
        hazard1.active = False
        hazard2.active = False
        lock1.active = False
        lock2.active = False
        textbox1.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox2.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox3.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox4.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox5.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox6.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox7.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox8.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox9.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "3"
        
    def room4():
        #Subroutine which draws room 4 when called.
        ground1.Redefine(0, 0, 250, 500, BLACK, False, False, False, False, 0.25)
        ground2.Redefine(430, 0, 270, 500, BLACK, False, False, False, False, 0.25)
        water.active = False
        ground1.active = True
        ground2.active = True
        ground3.active = False
        ground4.active = False
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        ramp1.active = False
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = False
        hazard1.active = False
        hazard2.active = False
        lock1.active = False
        lock2.active = False
        textbox1.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox2.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox3.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox4.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox5.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox6.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox7.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox8.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox9.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "4"
        
    def room5():
        #Subroutine which draws room 5 when called.
        ground1.Redefine(100, -100, 150, 150, BLACK, False, False, False, False, 0.25)
        ground2.Redefine(0, 100, 250, 400, BLACK, False, False, False, False, 0.25)
        ground3.Redefine(430, 0, 270, 270, BLACK, False, False, False, False, 0.25)
        ground4.Redefine(430, 450, 200, 50, BLACK, False, False, False, False, 0.25)
        ground5.Redefine(690, 270, 10, 230, GREEN, False, False, False, True, 0.25)
        ground5.ids = True
        ground6.Redefine(0, 50, 25, 50, BLACK, False, False, False, False, 0.25)
        ramp1.Redefine(630, 450, 630, 500, 677.5, 500, BLACK, 20/19, -213.1578947, "Left", 1.0, 2.0, False, True, 10)
        key1.Redefine(500, 400)
        water.active = False
        ground1.active = True
        ground2.active = True
        ground3.active = True
        ground4.active = True
        ground5.active = True
        ground6.active = True
        ground7.active = False
        ground8.active = False
        ramp1.active = True
        ramp2.active = False
        ramp3.active = False
        key1.active = True
        key2.active = False
        hazard1.active = False
        hazard2.active = False
        lock1.active = False
        lock2.active = False
        textbox1.Redefine("As air is a surface, friction also applies", True, WHITE, 10, 125, "Calibri", 15, False, False)
        textbox2.Redefine("when objects move through the air.", True, WHITE, 10, 142, "Calibri", 15, False, False)
        textbox3.Redefine("This type of friction is a force known as", True, WHITE, 10, 167, "Calibri", 15, False, False)
        textbox4.Redefine("air resistance.", True, WHITE, 10, 184, "Calibri", 15, False, False)
        textbox5.Redefine("", True, WHITE, 10, 201, "Calibri", 15, False, False)
        textbox6.Redefine("The key below can be used to unlock the", True, WHITE, 440, 50, "Calibri", 15, False, False)
        textbox7.Redefine("barrier in the next room.", True, WHITE, 440, 67, "Calibri", 15, False, False)
        textbox8.Redefine("These green bars won't let you pass if you", True, WHITE, 440, 150, "Calibri", 15, False, False)
        textbox9.Redefine("hold right or are airborne  - can you use", True, WHITE, 440, 167, "Calibri", 15, False, False)
        textbox10.Redefine("something you've learnt to proceed?", True, WHITE, 440, 185, "Calibri", 15, False, False)
        if key_loaded == False:
            textbox11.Redefine("As you do not have the key image", True, RED, 10, 350, "Calibri", 15, False, False)
            textbox12.Redefine("downloaded or in the same location", True, RED, 10, 367, "Calibri", 15, False, False)
            textbox13.Redefine("as the program, keys will be represented", True, RED, 10, 384, "Calibri", 15, False, False)
            textbox14.Redefine("by purple boxes.", True, RED, 10, 401, "Calibri", 15, False, False)
        else:
            textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
            textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
            textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
            textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "5"
        
    def room6():
        #Subroutine which draws room 6 when called.
        ground1.Redefine(0, 0, 250, 300, BLACK, False, False, False, False, 0.25)
        ground2.Redefine(430, 0, 270, 300, BLACK, False, False, False, False, 0.25)
        ground3.Redefine(0, 400, 700, 100, BLACK, False, False, False, False, 0.25)
        water.active = False
        ground1.active = True
        ground2.active = True
        ground3.active = True
        ground4.active = False
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        ramp1.active = False
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = False
        hazard1.active = False
        hazard2.active = False
        lock1.active = False
        lock2.active = False
        textbox1.Redefine("You may have noticed that while", True, WHITE, 10, 50, "Calibri", 17, False, False)
        textbox2.Redefine("you were falling, your speed", True, WHITE, 10, 75, "Calibri", 17, False, False)
        textbox3.Redefine("stopped increasing after a while.", True, WHITE, 10, 100, "Calibri", 17, False, False)
        textbox4.Redefine("This is because you reached the", True, WHITE, 445, 50, "Calibri", 17, False, False)
        textbox5.Redefine("ball's terminal velocity, which is", True, WHITE, 445, 75, "Calibri", 17, False, False)
        textbox6.Redefine("its maximum falling speed.", True, WHITE, 445, 100, "Calibri", 17, False, False)
        textbox7.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox8.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox9.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "6"
        
    def room7():
        #Subroutine which draws room 7 when called.
        ground1.Redefine(560, 210, 140, 300, BLACK, False, False, False, False, 0.25)
        ground2.Redefine(0, 350, 560, 150, BLACK, False, False, False, False, 0.25)
        ground3.Redefine(0, 0, 490, 235, BLACK, False, False, False, False, 0.25)
        ground4.Redefine(490, 210, 70, 25, RED, False, True, True, True, 0.25)
        water.active = False
        ground1.active = True
        ground2.active = True
        ground3.active = True
        ground4.active = True
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        ramp1.active = False
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = False
        hazard1.active = False
        hazard2.active = False
        lock1.active = False
        lock2.active = False
        textbox1.Redefine("The red rectangle is a semisolid.", True, WHITE, 120, 82, "Calibri", 18, False, False)
        textbox2.Redefine("Semisolids allow you to pass through one of their sides,", True, WHITE, 45, 107, "Calibri", 18, False, False)
        textbox3.Redefine("but will act like regular terrain from all of their other sides.", True, WHITE, 35, 132, "Calibri", 18, False, False)
        textbox4.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox5.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox6.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox7.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox8.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox9.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "7"
        
    def room8():
        #Subroutine which draws room 8 when called.
        ground1.Redefine(0, 400, 700, 100, BLACK, False, False, False, False, 0.25)
        ground2.Redefine(0, 300, 200, 100, BLACK, False, False, False, False, 0.25)
        ground3.Redefine(650, 0, 50, 251, BLACK, False, False, False, False, 0.25)
        ground4.Redefine(500, 150, 150, 101, BLACK, False, False, False, False, 0.25)
        ground5.Redefine(0, 25, 315, 101, BLACK, False, False, False, False, 0.25)
        ground6.Redefine(0, 125, 50, 175, BLACK, False, False, False, False, 0.25)
        ground7.Redefine(0, -25, 215, 50, BLACK, False, False, False, False, 0.25)
        ground8.Redefine(310, -25, 5, 50, RED, False, False, False, True, 0.25)
        ramp1.Redefine(200, 300, 200, 400, 560, 400, BLACK, 5/18, 2200/9, "Left", 0.6, 1.4, True, True, 0)
        ramp2.Redefine(280, 250, 500, 250, 500, 150, BLACK, -5/11, 4150/11 - 10, "Right", 1.5, 0.5, True, False, 0)
        ramp3.Redefine(315, 25, 315, 125, 415, 125, BLACK, 1, -300 + 10, "Left", 0.4, 1.6, False, True, 10)
        water.active = False
        ground1.active = True
        ground2.active = True
        ground3.active = True
        ground4.active = True
        ground5.active = True
        ground6.active = True
        ground7.active = True
        ground8.active = True
        ramp1.active = True
        ramp2.active = True
        ramp3.active = True
        key1.active = False
        key2.active = False
        hazard1.active = False
        hazard2.active = False
        lock1.active = False
        lock2.active = False
        textbox1.Redefine("When climbing up ramps, your", True, WHITE, 45, 350, "Calibri", 18, False, False)
        textbox2.Redefine("movement will be slowed down.", True, WHITE, 45, 370, "Calibri", 18, False, False)
        textbox3.Redefine("Conversely, you will travel", True, WHITE, 500, 170, "Calibri", 18, False, False)
        textbox4.Redefine("faster when going down", True, WHITE, 500, 190, "Calibri", 18, False, False)
        textbox5.Redefine("them.", True, WHITE, 500, 210, "Calibri", 18, False, False)
        textbox6.Redefine("This is because gravity", True, WHITE, 35, 40, "Calibri", 18, False, False)
        textbox7.Redefine("pulls the ball down", True, WHITE, 35, 60, "Calibri", 18, False, False)
        textbox8.Redefine("the incline.", True, WHITE, 35, 80, "Calibri", 18, False, False)
        textbox9.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "8"
        
    def room9():
        #Subroutine which draws room 9 when called.
        ground1.Redefine(0, 400, 420, 100, BLACK, False, False, False, False, 0.25)
        ground2.Redefine(560, 0, 140, 500, BLACK, False, False, False, False, 0.25)
        ground3.Redefine(390, 0, 250, 200, BLACK, False, False, False, False, 0.25)
        lock1.Redefine(390, 200, 30, 200)
        ramp1.Redefine(0, 0, 0, 200, 190, 200, BLACK, 20/19, 0, "Left", 1.0, 2.0, False, False, 0)
        water.active = False
        ground1.active = True
        ground2.active = True
        ground3.active = True
        ground4.active = False
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        ramp1.active = True
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = False
        hazard1.active = False
        hazard2.active = False
        lock1.active = True
        lock2.active = False
        if key1.used == False:
            textbox1.Redefine("You need a key to unlock the barrier.", True, BLACK, 35, 230, "Calibri", 22, False, False)
            textbox2.Redefine("Follow the other path first.", True, BLACK, 73, 290, "Calibri", 22, False, False)
        else:
            textbox1.Redefine("Good job!", True, BLACK, 150, 230, "Calibri", 22, False, False)
            textbox2.Redefine("Now unlock the barrier by moving into it.", True, BLACK, 20, 290, "Calibri", 22, False, False)
        textbox3.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox4.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox5.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox6.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox7.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox8.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox9.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "9"
        
    def room10():
        #Subroutine which draws room 10 when called.
        ground1.Redefine(0, 400, 600, 100, I_BLUE, False, False, False, False, 0.125)
        ground2.Redefine(560, 0, 140, 500, BLACK, False, False, False, False, 0.25)
        ground3.Redefine(0, 0, 420, 100, BLACK, False, False, False, False, 0.25)
        water.active = False
        ground1.active = True
        ground2.active = True
        ground3.active = True
        ground4.active = False
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        ramp1.active = False
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = False
        hazard1.active = False
        hazard2.active = False
        lock1.active = False
        lock2.active = False
        textbox1.Redefine("The terrain you're currently standing on is ice, which has a very low amount of friction.", True, BLACK, 10, 125, "Calibri", 15, False, False)
        textbox2.Redefine("This means that the ball will take longer to come to a stop while travelling across it.", True, BLACK, 10, 150, "Calibri", 15, False, False)
        textbox3.Redefine("However, friction also allows objects to grip onto surfaces, which is what gives them the", True, BLACK, 10, 175, "Calibri", 15, False, False)
        textbox4.Redefine("ability to move in the first place.", True, BLACK, 10, 192, "Calibri", 15, False, False)
        textbox5.Redefine("As a result, this means the ball will also take longer to accelerate while on ice.", True, BLACK, 10, 217, "Calibri", 15, False, False)
        textbox6.Redefine("", True, BLACK, 10, 234, "Calibri", 15, False, False)
        textbox7.Redefine("", True, BLACK, 10, 259, "Calibri", 15, False, False)
        textbox8.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox9.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "10"
        
    def room11():
        #Subroutine which draws room 11 when called.
        ground1.Redefine(0, 400, 700, 100, I_BLUE, False, False, False, False, 0.125)
        hazard1.Redefine(150, 362.5, 37.5, 37.5, "Right", 500, 362.5)
        hazard1.sp = 1
        water.active = False
        ground1.active = True
        ground2.active = False
        ground3.active = False
        ground4.active = False
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        ramp1.active = False
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = False
        hazard1.active = True
        hazard2.active = False
        lock1.active = False
        lock2.active = False
        textbox1.Redefine("The yellow square is a hazard.", True, BLACK, 225, 100, "Calibri", 22, False, False)
        textbox2.Redefine("If you touch a hazard, you'll be sent back", True, BLACK, 190, 150, "Calibri", 22, False, False)
        textbox3.Redefine("to the point you entered the room from.", True, BLACK, 192, 175, "Calibri", 22, False, False)
        textbox4.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox5.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox6.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox7.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox8.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox9.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "11"
        
    def room12():
        #Subroutine which draws room 12 when called.
        ground1.Redefine(300, 250, 400, 250, I_BLUE, False, False, False, False, 0.125)
        ground2.Redefine(0, 0, 100, 500, BLACK, False, False, False, False, 0.25)
        hazard1.Redefine(100, 350, 50, 50, "Right", 250, 350)
        hazard1.sp = 2
        water.Redefine(100, 400, 200, 100)
        water.active = True
        ground1.active = True
        ground2.active = True
        ground3.active = False
        ground4.active = False
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        ramp1.active = False
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = False
        hazard1.active = True
        hazard2.active = False
        lock1.active = False
        lock2.active = False
        textbox1.Redefine("This hazard is guarding a body of water.", True, BLACK, 360, 300, "Calibri", 18, False, False)
        textbox2.Redefine("The ball will sink when it hits the water", True, BLACK, 347.5, 350, "Calibri", 18, False, False)
        textbox3.Redefine("since it has higher density.", True, BLACK, 400, 375, "Calibri", 18, False, False)
        textbox4.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox5.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox6.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox7.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox8.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox9.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "12"
        
    def room13():
        #Subroutine which draws room 13 when called.
        water.Redefine(0, 0, 700, 500)
        ground1.Redefine(0, 0, 100, 350, BLACK, False, False, False, False, 0.25)
        ground2.Redefine(300, 0, 400, 151, BLACK, False, False, False, False, 0.25)
        ground3.Redefine(0, 450, 350, 100, BLACK, False, False, False, False, 0.25)
        ground4.Redefine(450, 450, 250, 100, BLACK, False, False, False, False, 0.25)
        lock2.Redefine(0, 350, 50, 100)
        hazard1.Redefine(375, 400, 50, 50, "Up", 375, 150)
        hazard1.sp = 1
        hazard2.Redefine(350, 450, 100, 100, "Up", 350, 450)
        hazard2.sp = 0
        water.active = True
        ground1.active = True
        ground2.active = True
        ground3.active = True
        ground4.active = True
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        ramp1.active = False
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = False
        hazard1.active = True
        hazard2.active = True
        lock1.active = False
        lock2.active = True
        textbox1.Redefine("While underwater, the ball's movement is much more restricted.", True, WHITE, 310, 10, "Calibri", 12, False, False)
        textbox2.Redefine("Although the ball sinks as it has higher density than the water,", True, WHITE, 310, 27, "Calibri", 12, False, False)
        textbox3.Redefine("there is a force pushing against the one causing it to sink.", True, WHITE, 310, 45, "Calibri", 12, False, False)
        textbox4.Redefine("This upward force is the object's buoyancy.", True, WHITE, 310, 70, "Calibri", 12, False, False)
        textbox5.Redefine("Jumping will provide the force required for the total upward force to outweigh", True, WHITE, 310, 87, "Calibri", 12, False, False)
        textbox6.Redefine("the total downward force, making the ball rise to the surface for a short", True, WHITE, 310, 105, "Calibri", 12, False, False)
        textbox7.Redefine("while until the force of gravity causes it to sink once more.", True, WHITE, 310, 122, "Calibri", 12, False, False)
        if player.keyhold == True:
            textbox8.Redefine("Nicely done! Now pass through", True, BLACK, 110, 250, "Calibri", 18, False, False)
            textbox9.Redefine("the barrier to finish the game.", True, BLACK, 110, 275, "Calibri", 18, False, False)
        else:
            textbox8.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
            textbox9.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "13"
        
    def room14():
        #Subroutine which draws room 14 when called.
        water.Redefine(0, 0, 700, 500)
        ground1.Redefine(0, 375, 301, 125, BLACK, False, False, False, False, 0.25)
        ground2.Redefine(301, 275, 224, 225, BLACK, False, False, False, False, 0.25)
        ground3.Redefine(525, 150, 175, 350, BLACK, False, False, False, False, 0.25)
        ground4.Redefine(0, 0, 700, 75, BLACK, False, False, False, False, 0.25)
        ground5.Redefine(0, 0, 301, 200, BLACK, False, False, False, False, 0.25)
        key1.Redefine(600, 100)
        water.active = True
        ground1.active = True
        ground2.active = True
        ground3.active = True
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        ramp1.active = False
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = True
        hazard1.active = True
        hazard2.active = True
        lock1.active = False
        lock2.active = False
        textbox1.Redefine("", True, BLACK, 35, 230, "Calibri", 22, False, False)
        textbox2.Redefine("", True, BLACK, 73, 290, "Calibri", 22, False, False)
        textbox3.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox4.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox5.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox6.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox7.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox8.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox9.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        #Puts the hazards in their correct positions before determining whether they should move.
        if player.room != "14":
            hazard1.Redefine(250, 375, 50, 50, "Up", 250, 150)
            hazard2.Redefine(475, 275, 50, 50, "Up", 475, 25)
        if key2.used == False:
            hazard1.sp = 0
            hazard2.sp = 0
            ground4.active = False
            ground5.active = False
        else:
            hazard1.sp = 1.25
            hazard2.sp = 1
            ground4.active = True
            ground5.active = True
        player.room = "14"
        
    def room15():
        #Subroutine which draws room 15 when called.
        water.Redefine(550, 350, 150, 150)
        ground1.Redefine(0, 350, 150, 150, BLACK, False, False, False, False, 0.25)
        ground2.Redefine(250, 350, 300, 150, BLACK, False, False, False, False, 0.25)
        ground3.Redefine(550, 450, 150, 50, BLACK, False, False, False, False, 0.25)
        water.active = True
        ground1.active = True
        ground2.active = True
        ground3.active = True
        ground4.active = False
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        ramp1.active = False
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = False
        hazard1.active = False
        hazard2.active = False
        lock1.active = False
        lock2.active = False
        if quiz == False:
            textbox1.Redefine("Now you've completed the game portion of the program, you'll now be answering a quick", True, BLACK, 50, 50, "Calibri", 18, False, False)
            textbox2.Redefine("quiz based on the material showcased in the game to reinforce your learning.", True, BLACK, 50, 75, "Calibri", 18, False, False)
            textbox3.Redefine("For each question, you will be presented with three choices (with each choice", True, BLACK, 50, 125, "Calibri", 18, False, False)
            textbox4.Redefine("corresponding to a hole in the ground).", True, BLACK, 50, 150, "Calibri", 18, False, False)
            textbox5.Redefine("Getting any question wrong will send you back to this room.", True, BLACK, 50, 200, "Calibri", 18, False, False)
            textbox6.Redefine("Go into the hole to proceed.", True, BLACK, 50, 250, "Calibri", 18, False, False)
        else:
            textbox1.Redefine("Incorrect answer", True, RED, 50, 50, "Calibri", 18, False, False)
            textbox2.Redefine(" - try again by re-entering the hole.", True, BLACK, 175, 50, "Calibri", 18, False, False)
            textbox3.Redefine("", True, BLACK, 50, 125, "Calibri", 18, False, False)
            textbox4.Redefine("", True, BLACK, 50, 150, "Calibri", 18, False, False)
            textbox5.Redefine("", True, BLACK, 50, 200, "Calibri", 18, False, False)
            textbox6.Redefine("", True, BLACK, 50, 250, "Calibri", 18, False, False)
        textbox7.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox8.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox9.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "15"
        
    def room16():
        #Subroutine which draws room 16 when called.
        global answers
        answers = ["Terminal velocity.", "Final speed.", "Ultimate acceleration."]
        shuffle(answers)
        ground1.Redefine(0, 300, 137.5, 200, BLACK, False, False, False, False, 0.25)
        ground2.Redefine(212.5, 300, 100, 200, BLACK, False, False, False, False, 0.25)
        ground3.Redefine(387.5, 300, 100, 200, BLACK, False, False, False, False, 0.25)
        ground4.Redefine(562.5, 300, 137.5, 200, BLACK, False, False, False, False, 0.25)
        water.active = False
        ground1.active = True
        ground2.active = True
        ground3.active = True
        ground4.active = True
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        ramp1.active = False
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = False
        hazard1.active = False
        hazard2.active = False
        lock1.active = False
        lock2.active = False
        textbox1.Redefine("Question 1 of 5:", True, BLACK, 20, 20, "Calibri", 18, False, False)
        textbox2.Redefine("What is an object's maximum falling speed known as?", True, BLACK, 20, 57.5, "Calibri", 18, False, False)
        textbox3.Redefine(f"A = {answers[0]}", True, BLACK, 20, 95, "Calibri", 18, False, False)
        textbox4.Redefine(f"B = {answers[1]}", True, BLACK, 20, 120, "Calibri", 18, False, False)
        textbox5.Redefine(f"C = {answers[2]}", True, BLACK, 20, 145, "Calibri", 18, False, False)
        textbox6.Redefine("A", True, BLACK, 171.5, 225, "Calibri", 18, False, False)
        textbox7.Redefine("B", True, BLACK, 346.5, 225, "Calibri", 18, False, False)
        textbox8.Redefine("C", True, BLACK, 521.5, 225, "Calibri", 18, False, False)
        textbox9.Redefine("", True, GREEN, 275, 0, "Calibri", 50, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "16"
        
    def room17():
        #Subroutine which draws room 17 when called.
        global answers
        answers = ["The force which pulls objects towards the ground.", "The force which slows the movement of two objects when their surfaces collide.", "The force which pushes upwards against objects which are underwater."]
        shuffle(answers)
        ground1.Redefine(0, 300, 137.5, 200, BLACK, False, False, False, False, 0.25)
        ground2.Redefine(212.5, 300, 100, 200, BLACK, False, False, False, False, 0.25)
        ground3.Redefine(387.5, 300, 100, 200, BLACK, False, False, False, False, 0.25)
        ground4.Redefine(562.5, 300, 137.5, 200, BLACK, False, False, False, False, 0.25)
        water.active = False
        ground1.active = True
        ground2.active = True
        ground3.active = True
        ground4.active = True
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        ramp1.active = False
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = False
        hazard1.active = False
        hazard2.active = False
        lock1.active = False
        lock2.active = False
        textbox1.Redefine("Question 2 of 5:", True, BLACK, 20, 20, "Calibri", 18, False, False)
        textbox2.Redefine("What is buoyancy?", True, BLACK, 20, 57.5, "Calibri", 18, False, False)
        textbox3.Redefine(f"A = {answers[0]}", True, BLACK, 20, 95, "Calibri", 18, False, False)
        textbox4.Redefine(f"B = {answers[1]}", True, BLACK, 20, 120, "Calibri", 18, False, False)
        textbox5.Redefine(f"C = {answers[2]}", True, BLACK, 20, 145, "Calibri", 18, False, False)
        textbox6.Redefine("A", True, BLACK, 171.5, 225, "Calibri", 18, False, False)
        textbox7.Redefine("B", True, BLACK, 346.5, 225, "Calibri", 18, False, False)
        textbox8.Redefine("C", True, BLACK, 521.5, 225, "Calibri", 18, False, False)
        textbox9.Redefine("Correct!", True, GREEN, 275, 0, "Calibri", 50, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "17"
        
    def room18():
        #Subroutine which draws room 18 when called.
        global answers
        answers = ["When two surfaces bounce off each other.", "When two surfaces collide into each other.", "When two surfaces slide over each other."]
        shuffle(answers)
        ground1.Redefine(0, 300, 137.5, 200, BLACK, False, False, False, False, 0.25)
        ground2.Redefine(212.5, 300, 100, 200, BLACK, False, False, False, False, 0.25)
        ground3.Redefine(387.5, 300, 100, 200, BLACK, False, False, False, False, 0.25)
        ground4.Redefine(562.5, 300, 137.5, 200, BLACK, False, False, False, False, 0.25)
        water.active = False
        ground1.active = True
        ground2.active = True
        ground3.active = True
        ground4.active = True
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        ramp1.active = False
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = False
        hazard1.active = False
        hazard2.active = False
        lock1.active = False
        lock2.active = False
        textbox1.Redefine("Question 3 of 5:", True, BLACK, 20, 20, "Calibri", 18, False, False)
        textbox2.Redefine("When does friction occur?", True, BLACK, 20, 57.5, "Calibri", 18, False, False)
        textbox3.Redefine(f"A = {answers[0]}", True, BLACK, 20, 95, "Calibri", 18, False, False)
        textbox4.Redefine(f"B = {answers[1]}", True, BLACK, 20, 120, "Calibri", 18, False, False)
        textbox5.Redefine(f"C = {answers[2]}", True, BLACK, 20, 145, "Calibri", 18, False, False)
        textbox6.Redefine("A", True, BLACK, 171.5, 225, "Calibri", 18, False, False)
        textbox7.Redefine("B", True, BLACK, 346.5, 225, "Calibri", 18, False, False)
        textbox8.Redefine("C", True, BLACK, 521.5, 225, "Calibri", 18, False, False)
        textbox9.Redefine("Correct!", True, GREEN, 275, 0, "Calibri", 50, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "18"
        
    def room19():
        #Subroutine which draws room 19 when called.
        global answers
        answers = ["They will take less time to accelerate and decelerate.", "They will take more time to accelerate and decelerate.", "It won't affect the objects."]
        shuffle(answers)
        ground1.Redefine(0, 300, 137.5, 200, BLACK, False, False, False, False, 0.25)
        ground2.Redefine(212.5, 300, 100, 200, BLACK, False, False, False, False, 0.25)
        ground3.Redefine(387.5, 300, 100, 200, BLACK, False, False, False, False, 0.25)
        ground4.Redefine(562.5, 300, 137.5, 200, BLACK, False, False, False, False, 0.25)
        water.active = False
        ground1.active = True
        ground2.active = True
        ground3.active = True
        ground4.active = True
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        ramp1.active = False
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = False
        hazard1.active = False
        hazard2.active = False
        lock1.active = False
        lock2.active = False
        textbox1.Redefine("Question 4 of 5:", True, BLACK, 20, 20, "Calibri", 18, False, False)
        textbox2.Redefine("If a surface has low friction, how will it affect objects moving across it?", True, BLACK, 20, 57.5, "Calibri", 18, False, False)
        textbox3.Redefine(f"A = {answers[0]}", True, BLACK, 20, 95, "Calibri", 18, False, False)
        textbox4.Redefine(f"B = {answers[1]}", True, BLACK, 20, 120, "Calibri", 18, False, False)
        textbox5.Redefine(f"C = {answers[2]}", True, BLACK, 20, 145, "Calibri", 18, False, False)
        textbox6.Redefine("A", True, BLACK, 171.5, 225, "Calibri", 18, False, False)
        textbox7.Redefine("B", True, BLACK, 346.5, 225, "Calibri", 18, False, False)
        textbox8.Redefine("C", True, BLACK, 521.5, 225, "Calibri", 18, False, False)
        textbox9.Redefine("Correct!", True, GREEN, 275, 0, "Calibri", 50, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "19"
        
    def room20():
        #Subroutine which draws room 20 when called.
        global answers
        answers = ["A type of friction.", "A type of tension.", "A type of resistance."]
        shuffle(answers)
        ground1.Redefine(0, 300, 137.5, 200, BLACK, False, False, False, False, 0.25)
        ground2.Redefine(212.5, 300, 100, 200, BLACK, False, False, False, False, 0.25)
        ground3.Redefine(387.5, 300, 100, 200, BLACK, False, False, False, False, 0.25)
        ground4.Redefine(562.5, 300, 137.5, 200, BLACK, False, False, False, False, 0.25)
        water.active = False
        ground1.active = True
        ground2.active = True
        ground3.active = True
        ground4.active = True
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        ramp1.active = False
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = False
        hazard1.active = False
        hazard2.active = False
        lock1.active = False
        lock2.active = False
        textbox1.Redefine("Question 5 of 5:", True, BLACK, 20, 20, "Calibri", 18, False, False)
        textbox2.Redefine("What type of force is air resistance?", True, BLACK, 20, 57.5, "Calibri", 18, False, False)
        textbox3.Redefine(f"A = {answers[0]}", True, BLACK, 20, 95, "Calibri", 18, False, False)
        textbox4.Redefine(f"B = {answers[1]}", True, BLACK, 20, 120, "Calibri", 18, False, False)
        textbox5.Redefine(f"C = {answers[2]}", True, BLACK, 20, 145, "Calibri", 18, False, False)
        textbox6.Redefine("A", True, BLACK, 171.5, 225, "Calibri", 18, False, False)
        textbox7.Redefine("B", True, BLACK, 346.5, 225, "Calibri", 18, False, False)
        textbox8.Redefine("C", True, BLACK, 521.5, 225, "Calibri", 18, False, False)
        textbox9.Redefine("Correct!", True, GREEN, 275, 0, "Calibri", 50, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "20"
        
    def room21():
        #Subroutine which draws room 21 when called.
        ground1.Redefine(0, 400, 700, 100, BLACK, False, False, False, False, 0.25)
        water.active = False
        ground1.active = True
        ground2.active = False
        ground3.active = False
        ground4.active = False
        ground5.active = False
        ground6.active = False
        ground7.active = False
        ground8.active = False
        ramp1.active = False
        ramp2.active = False
        ramp3.active = False
        key1.active = False
        key2.active = False
        hazard1.active = False
        hazard2.active = False
        lock1.active = False
        lock2.active = False
        textbox1.Redefine("Congratulations!", True, BLACK, 182.5, 20, "Calibri", 50, False, False)
        textbox2.Redefine("You have completed the game.", True, BLACK, 237.5, 100, "Calibri", 18, False, False)
        textbox3.Redefine("This should have given you a good introduction to the fundamental forces of Physics.", True, BLACK, 50, 137.5, "Calibri", 18, False, False)
        if minutes == 1 and seconds == 1:
            textbox4.Redefine(f"You finished the game in {minutes} minute and {seconds} second  - think you can do better?", True, BLACK, 82 - (2.5 * (len(str(minutes)) + (len(str(seconds))))), 175, "Calibri", 18, False, False)
        elif minutes == 1:
            textbox4.Redefine(f"You finished the game in {minutes} minute and {seconds} seconds  - think you can do better?", True, BLACK, 82 - (2.5 * (len(str(minutes)) + (len(str(seconds))))), 175, "Calibri", 18, False, False)
        elif seconds == 1:
            textbox4.Redefine(f"You finished the game in {minutes} minutes and {seconds} second  - think you can do better?", True, BLACK, 82 - (2.5 * (len(str(minutes)) + (len(str(seconds))))), 175, "Calibri", 18, False, False)
        else:  
            textbox4.Redefine(f"You finished the game in {minutes} minutes and {seconds} seconds  - think you can do better?", True, BLACK, 82 - (2.5 * (len(str(minutes)) + (len(str(seconds))))), 175, "Calibri", 18, False, False)
        textbox5.Redefine("Press the Space Bar to reset the game.", True, BLACK, 160, 225, "Calibri", 25, False, False)
        textbox6.Redefine("", True, BLACK, 284, 200, "Calibri", 18, False, False)
        textbox7.Redefine("", True, BLACK, 434, 200, "Calibri", 18, False, False)
        textbox8.Redefine("", True, BLACK, 584, 200, "Calibri", 18, False, False)
        textbox9.Redefine("", True, GREEN, 275, 0, "Calibri", 50, False, False)
        textbox10.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox11.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox12.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox13.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        textbox14.Redefine("", True, BLACK, 210, 50, "Calibri", 25, False, False)
        player.room = "21"
        
        
    def draw():
        if player.room == "title":
            screen.fill(BLACK)
            font = pygame.font.SysFont('Calibri', 50, False, False)
            text = font.render("Introduction to Forces", True, (0, 0, 255))
            screen.blit(text, [130, 200])
            font = pygame.font.SysFont('Times New Roman', 25, False, False)
            text = font.render("Press the Space Bar to play!", True, (45, 45, 112))
            screen.blit(text, [205, 350])
            font = pygame.font.SysFont('Calibri', 37, False, False)
            pygame.display.flip()      
            
        else:
            screen.fill(WHITE)
            #Continually draws room 14 while the player is traversing it so its layout can change when the player picks up the key inside it.
            if player.room == "14":
                room14()
            if water.active == True:
                pygame.draw.rect(screen, W_BLUE, [water.x, water.y, water.w, water.h])
            if ground1.active == True:
                pygame.draw.rect(screen, ground1.c, [ground1.x, ground1.y, ground1.w, ground1.h])
            if ground2.active == True:
                pygame.draw.rect(screen, ground2.c, [ground2.x, ground2.y, ground2.w, ground2.h])
            if ground3.active == True:
                pygame.draw.rect(screen, ground3.c, [ground3.x, ground3.y, ground3.w, ground3.h])
            if ground4.active == True:
                pygame.draw.rect(screen, ground4.c, [ground4.x, ground4.y, ground4.w, ground4.h])
            if ground5.active == True:
                pygame.draw.rect(screen, ground5.c, [ground5.x, ground5.y, ground5.w, ground5.h])
            if ground6.active == True:
                pygame.draw.rect(screen, ground6.c, [ground6.x, ground6.y, ground6.w, ground6.h])
            if ground7.active == True:
                pygame.draw.rect(screen, ground7.c, [ground7.x, ground7.y, ground7.w, ground7.h])
            if ground8.active == True:
                pygame.draw.rect(screen, ground8.c, [ground8.x, ground8.y, ground8.w, ground8.h])
            if ramp1.active == True:
                pygame.draw.polygon(screen, ramp1.c, ((ramp1.x1, ramp1.y1), (ramp1.x2, ramp1.y2), (ramp1.x3, ramp1.y3)))
            if ramp2.active == True:
                pygame.draw.polygon(screen, ramp2.c, ((ramp2.x1, ramp2.y1), (ramp2.x2, ramp2.y2), (ramp2.x3, ramp2.y3)))
            if ramp3.active == True:
                pygame.draw.polygon(screen, ramp3.c, ((ramp3.x1, ramp3.y1), (ramp3.x2, ramp3.y2), (ramp3.x3, ramp3.y3)))
            if key1.active == True and player.keyhold == False and key1.used == False:
                if key_loaded == True:
                    screen.blit(key1.image, [key1.x, key1.y])
                else:
                    pygame.draw.rect(screen, key1.colour, [key1.x, key1.y, key1.w, key1.h])
            if key2.active == True and player.keyhold == False and key2.used == False:
                if key_loaded == True:
                    screen.blit(key2.image, [key2.x, key2.y])
                else:
                    pygame.draw.rect(screen, key2.colour, [key2.x, key2.y, key2.w, key2.h])
            if lock1.active == True and lock1.locked == True:
                pygame.draw.rect(screen, PURPLE, [lock1.x, lock1.y, lock1.w, lock1.h])
            if lock2.active == True and lock2.locked == True:
                pygame.draw.rect(screen, PURPLE, [lock2.x, lock2.y, lock2.w, lock2.h])
            if hazard1.active == True:
                pygame.draw.rect(screen, hazard1.colour, [hazard1.x, hazard1.y, hazard1.w, hazard1.h])
            if hazard2.active == True:
                pygame.draw.rect(screen, hazard2.colour, [hazard2.x, hazard2.y, hazard2.w, hazard2.h])
            textbox1.Write()
            textbox2.Write()
            textbox3.Write()
            textbox4.Write()
            textbox5.Write()
            textbox6.Write()
            textbox7.Write()
            textbox8.Write()
            textbox9.Write()
            textbox10.Write()
            textbox11.Write()
            textbox12.Write()
            textbox13.Write()
            textbox14.Write()
            pygame.draw.circle(screen, player.colour, [player.x, player.y], player.centre, player.radius)

    done = False
    player.room = "title"
    clock = pygame.time.Clock()
    xspawn = 0
    yspawn = 0
    rslow = False
    lslow = False
    rar = False
    lar = False
    right = False
    left = False
    change = False 
    rtemp = 0
    ltemp = 0 
    jump_buffer = False
    quiz = False
    time = 0
    
    while done == False:
 
        draw()
    
        for event in pygame.event.get():
            pygame.key.set_repeat(30)
            keyinput = pygame.key.get_pressed()
            
            if event.type == pygame.QUIT or keyinput[pygame.K_ESCAPE]:
                done = True
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_RIGHT or event.key == pygame.K_d: 
                    right = False
                    if player.room != "title" and player.room != "21" and player.jump == True:
                        if rslow == False:
                            player.racc = player.racc / 1.5
                            rslow = True
                if event.key == pygame.K_LEFT or event.key == pygame.K_a:
                    left = False
                    if player.room != "title" and player.room != "21" and player.jump == True:
                        player.lacc = player.lacc / 1.5
                        lslow = True
                if event.key == pygame.K_SPACE:
                    jump_buffer = False
            
        if player.jump == True:
            keyinput = pygame.key.get_pressed()
            if keyinput[pygame.K_SPACE]:
                    if player.room == "title" and jump_buffer == False:
                        room1()
                        player.x = 25
                        player.y = 25
                        player.jump = False
                        time = 0
                        xspawn = 25
                        yspawn = 175 
                    if player.room == "21":
                        player.room = "title"
                        jump_buffer = True
                        quiz = False
                        key1.used = False
                        key2.used = False
                        lock1.locked = True
                        lock2.locked = True
                    else:
                        if player.jump == True and jump_buffer == False:
                            player.ychange = -9 * player.bm
                            player.calcYSpeed(player.ychange)
                            player.jump = False
                            jump_buffer = True
             
            if (keyinput[pygame.K_RIGHT] or keyinput[pygame.K_d]) and (keyinput[pygame.K_LEFT] or keyinput[pygame.K_a]):
                if right == False and left == False:
                    right = True
                    left = True
             
            if keyinput[pygame.K_RIGHT] or keyinput[pygame.K_d]:
                if left == False and lslow == False and lar == False and player.rm != 0:
                    right = True
                    if player.lidle < 0:
                        player.lidle = player.lidle + (player.lm * 0.05)
                        player.calcXSpeed(player.lidle)
                    else:
                        player.lidle = 0.0
                    if player.lidle == 0.0 and player.room != "title" and player.room != "21":
                        if rslow == False:
                            player.calcXSpeed(player.racc)
                        if player.racc < ((40.0 * player.f * player.wr) * player.rm) and player.jump == True:
                            player.racc = player.racc + ((0.2 * player.f * player.wr) * player.rm)
                        if player.racc > (((40.0 * player.f * player.wr) * player.rm) + 1) and player.jump == True:
                            rslow = True
                            change = True
                        if player.racc <= ((40.0 * player.f * player.wr) * player.rm) and rslow == True:
                            rslow = False
                            if change == True:
                                player.racc = ((40.0 * player.f * player.wr) * player.rm)
                                change = False
            if keyinput[pygame.K_LEFT] or keyinput[pygame.K_a]:
                if right == False and rslow == False and rar == False and player.lm != 0:
                    left = True
                    if player.ridle > 0:
                        player.ridle = player.ridle - (player.rm * 0.05)
                        player.calcXSpeed(player.ridle)
                    else:
                        player.ridle = 0.0
                    if player.ridle == 0.0 and player.room != "title" and player.room != "21":
                            if lslow == False:
                                player.calcXSpeed(player.lacc)
                            if player.lacc > ((-40.0 * player.f * player.wr) * player.lm) and player.jump == True:
                                player.lacc = player.lacc - ((0.2 * player.f * player.wr) * player.lm)
                            if player.lacc < (((-40.0 * player.f * player.wr) * player.lm) - 1) and player.jump == True:
                                lslow = True
                                change = True
                            if player.lacc >= ((-40.0 * player.f * player.wr) * player.lm) and lslow == True:
                                 lslow = False
                                 if change == True:
                                    player.lacc = ((-40 * player.f * player.wr) * player.lm)
                                    change = False
                       
        
        if rslow == True:
                player.calcXSpeed(player.racc)
                if player.rm != 0:
                    player.racc = player.racc - ((0.25 * player.f * player.wr) / player.rm)  
                
        if lslow == True:
                player.calcXSpeed(player.lacc)
                if player.lm != 0:
                    player.lacc = player.lacc + (0.25 * player.f * player.wr / player.lm)
                
        if player.jump == False and rar == False:
            if player.racc > 0.0:
                rar = True
        if player.jump == False and lar == False:
            if player.lacc < 0.0:
                lar = True
        
        if rar == True:
            player.calcXSpeed(player.racc)
            if player.racc > player.ridle:
                player.racc = player.racc - 0.01
            rslow = False
        
        if lar == True:
            player.calcXSpeed(player.lacc)
            if player.lacc < player.lidle:
                player.lacc = player.lacc + 0.01
            lslow = False
            
        if (rar == True or lar == True) and player.jump == True:
            if player.lacc < 0.0:
                lslow = True
            if player.racc > 0.0: 
                rslow = True
            lar = False
            rar = False
          
        if player.racc < player.ridle and rslow == True:
            rslow = False
            player.racc = player.ridle
            
        if player.lacc > player.lidle and lslow == True:
            lslow = False
            player.lacc = player.lidle
         
        if player.rm - 1 > 0:
            if rtemp == player.rm and player.lacc == 0.0 and left == False and player.jump == True:
                if player.ridle < player.rm * 5:
                    player.ridle = player.ridle + (player.rm * 0.01)
                if right == False and rslow == False:
                    player.calcXSpeed(player.ridle)
                    player.racc = player.ridle
                if player.racc < player.ridle and rslow == True:
                    rslow = False
                    player.racc = player.ridle
        elif player.lm - 1 > 0:
            if ltemp == player.lm and player.racc == 0 and right == False and player.jump == True: 
                if player.lidle > player.lm * -5:
                    player.lidle = player.lidle - (player.lm * 0.01)
                if left == False and lslow == False:
                    player.calcXSpeed(player.lidle)
                    player.lacc = player.lidle
                if player.lacc > player.lidle and lslow == True:
                    lslow = False
                    player.lacc = player.lidle
        else:
            if player.ridle > 0:
                player.ridle = player.ridle - (player.rm * 0.01)
                if left == False and right == False and player.jump == True:
                    player.calcXSpeed(player.ridle)
            else:
                player.ridle = 0
            if player.lidle < 0:
                player.lidle = player.lidle + (player.lm * 0.01)
                if right == False and left == False and player.jump == True:
                    player.calcXSpeed(player.lidle)
            else:
                player.lidle = 0
             
            if player.lacc < 0 and right == False:
                player.racc = 0
            if player.racc > 0 and left == False:
                player.lacc = 0
                
        if (rtemp < 1 and player.rm > 1) or (rtemp > 1 and player.rm < 1) or (rtemp != player.rm and (rtemp > 1 and player.rm > 1)) and player.rm != 1:
            if player.ridle > 0:
                player.ridle = player.ridle - (player.rm * 0.01)
                if left == False:
                    player.calcXSpeed(player.ridle)
            else:
                player.ridle = 0
                rtemp = player.rm
         
        if (ltemp < 1 and player.lm > 1) or (ltemp > 1 and player.lm < 1) or (ltemp != player.lm and (ltemp > 1 and player.lm > 1)) and player.lm != 1:
            if player.lidle < 0:
                player.lidle = player.lidle + (player.lm * 0.01)
                if right == False:
                    player.calcXSpeed(player.lidle)
            else:
                player.lidle = 0
                ltemp = player.lm
                
        if player.jump == False:
            player.calcYSpeed(player.ychange)
            if player.ychange < 20:
                player.ychange = player.ychange + 0.5
                       
        if player.racc < 0:
            player.racc = 0.0
        if player.ridle < 0:
            player.ridle = 0.0
        if player.lacc > 0:
            player.lacc = 0.0
        if player.lidle > 0:
            player.lidle = 0.0
                
            
        if player.room != "title":
            ground1.TerrainCollision()
            ground2.TerrainCollision()
            ground3.TerrainCollision()
            ground4.TerrainCollision()
            ground5.TerrainCollision()
            ground6.TerrainCollision()
            ground7.TerrainCollision()
            ground8.TerrainCollision()
            ramp1.RampCollision()
            ramp2.RampCollision()
            ramp3.RampCollision()
            water.WaterCollision()
            lock1.LockCollision()
            lock2.LockCollision()
            hazard1.HazardMove(hazard1.sp)
            hazard1.HazardCollision()
            hazard1.BoundaryCheck()
            hazard2.HazardMove(hazard2.sp)
            hazard2.HazardCollision()
            hazard2.BoundaryCheck()
            key1.Pickup()
            key2.Pickup()
            if ground1.ground == False and ground2.ground == False and ground3.ground == False and ground4.ground == False and ground5.ground == False and ground6.ground == False and ground7.ground == False and ground8.ground == False and ramp1.ground == False and ramp2.ground == False and ramp3.ground == False:
                player.jump = False
        
        if player.room == "1":
        #Sets the screen boundaries for room 1 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.x < 25:
                player.x = 25
                player.lacc = 0.0
            if player.x > 700:
                if player.y < 200:
                    room2()
                    xspawn = 25
                    yspawn = 175
                    player.x = 0
                else:
                    room5()
                    player.x = 0
                    player.y = player.y - 400
            if player.x < 0 or player.y < 0 or player.y > 500:
                player.x = xspawn
                player.y = yspawn
                
        if player.room == "2":
        #Sets the screen boundaries for room 2 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.x < 0:
                room1()
                player.x = 700
                xspawn = 675
                yspawn = 175
            if player.x > 700:
                room3()
                player.x = 0
                xspawn = 25
                yspawn = 175
            if player.y < 0 or player.y > 500:
                player.x = xspawn
                player.y = yspawn
                            
        if player.room == "3":
        #Sets the screen boundaries for room 3 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.x < 0:
                room2()
                player.x = 700
                xspawn = 675
                yspawn = 175
            if player.y > 500:
                room4()
                xspawn = 275
                yspawn = 25
                player.y = 0
                player.x = player.x - 110
            if player.y < 0 or player.x > 700:
                player.x = xspawn
                player.y = yspawn
                
        if player.room == "4":
        #Sets the screen boundaries for room 4 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.y > 500:
                room5()
                player.y = 0
                xspawn = 25
                yspawn = 25
            if player.y < 0 or player.x < 0 or player.x > 700:
                player.x = xspawn
                player.y = yspawn
            
        if player.room == "5":
        #Sets the screen boundaries for room 5 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
             if player.y > 500:
                room6()
                xspawn = 275
                yspawn = 375
                player.y = 0
             if player.x < 0:
                room1()
                player.x = 700
                player.y = player.y + 400
                xspawn = 675
                yspawn = 425
             if player.x > 700:
                room9()
                player.x = 0
                player.y = player.y - 500
                xspawn = 25
                yspawn = 375
             if player.y < -100:
                player.x = xspawn
                player.y = yspawn
            
        if player.room == "6":
        #Sets the screen boundaries for room 6 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.x < 0:
                room7()
                player.x = 700
                player.y = player.y - 190
                xspawn = 675
                yspawn = 185
            if player.x > 700:
                room9()
                xspawn = 25
                yspawn = 375
                player.x = 0
            if player.y < 0 or player.y > 500:
                player.x = xspawn
                player.y = yspawn
                
        if player.room == "7":
        #Sets the screen boundaries for room 7 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.x < 0:
                room8()
                player.x = 700
                player.y = player.y + 50
                xspawn = 675
                yspawn = 375
            if player.x > 700:
                room6()
                player.x = 0
                player.y = player.y + 190
                xspawn = 275
                yspawn = 375
            if player.y < 0 or player.y > 500:
                player.x = xspawn
                player.y = yspawn
                
        if player.room == "8":
        #Sets the screen boundaries for room 8 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.x > 700:
                room7()
                player.x = 0
                player.y = player.y - 50
                xspawn = 675
                yspawn = 185
            if player.y < -1 and player.x <= 285:
                room1()
                player.y = 500
                xspawn = 25
                yspawn = 425
            if player.y < -50 or player.y > 500 or player.x < 0 or (player.y < -1 and player.x > 625):
                player.x = xspawn
                player.y = yspawn
                
                
        if player.room == "9":
        #Sets the screen boundaries for room 9 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.x < 25:
                if player.y > 200:
                    if player.x < 0:
                        room6()
                        player.x = 700
                        xspawn = 275
                        yspawn = 375
                else:
                    player.x = 25
                    player.lacc = 0.0
                    player.lidle = 0.0
            if player.y > 500:
                room10()
                xspawn = 535
                yspawn = 375
                player.y = 0
            if player.x > 700 or player.y < -50:
                player.x = xspawn
                player.y = yspawn
            
                
        if player.room == "10":
        #Sets the screen boundaries for room 10 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.x < 0:
                room11()
                player.x = 700
                xspawn = 675
                yspawn = 375
            if player.x > 700 or player.y < 0 or player.y > 500:
                player.x = xspawn
                player.y = yspawn
                
        if player.room == "11":
        #Sets the screen boundaries for room 11 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.x > 700:
                room10()
                player.x = 0
                xspawn = 535
                yspawn = 375
            if player.x < 0:
                room12()
                player.x = 700
                player.y = player.y - 150
                xspawn = 675
                yspawn = 225
            if player.y < 0 or player.y > 500:
                player.x = xspawn
                player.y = yspawn
                
        if player.room == "12":
        #Sets the screen boundaries for room 12 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.x > 700:
                room11()
                player.x = 0
                player.y = player.y + 150
                xspawn = 25
                yspawn = 375
            if player.y > 500:
                room13()
                player.y = 0 
                xspawn = 150
                yspawn = 425
            if player.x < 0 or player.y < 0:
                player.x = xspawn
                player.y = yspawn
        
        if player.room == "13":
        #Sets the screen boundaries for room 13 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.x > 700:
                room14()
                player.x = 0
                player.y = player.y - 75
                xspawn = 25
                yspawn = 350
            if player.x < 0:
                room15()
                player.x = 700
                player.y = 425
                xspawn = 525
                yspawn = 325
            if player.y < -50 or player.y > 500:
                player.x = xspawn
                player.y = yspawn
        
        if player.room == "14":
        #Sets the screen boundaries for room 14 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.x < 0:
                room13()
                player.x = 700
                player.y = player.y + 75
                xspawn = 675
                yspawn = 425
            if player.x > 675:
                player.x = 675
                player.racc = 0.0
                player.ridle = 0.0
            if player.keyhold == True and player.room == "14":
                if player.x + player.radius > hazard2.x:
                    xspawn = 675
                    yspawn = 125
                if player.x < hazard1.x - player.radius:
                    xspawn = 25
                    yspawn = 350
                else:
                    xspawn = 413
                    yspawn = 250
            if player.y < 0 or player.y > 500:
                player.x = xspawn
                player.y = yspawn
                    
        if player.room == "15":
        #Sets the screen boundaries for room 15 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.x > 675:
                player.x = 675
                player.racc = 0.0
                player.ridle = 0.0
            if player.x < 25:
                player.x = 25
                player.lacc = 0.0
                player.lidle = 0.0
            if player.y > 500:
                room16()
                quiz = True
                player.y = 0
                player.x = player.x - 150
                xspawn = 25
                yspawn = 25
                player.racc = 0.0
                player.lacc = 0.0
                player.ridle = 0.0
                player.lidle = 0.0
            if player.y < 0 or player.x < 0 or player.x > 700:
                player.x = xspawn
                player.y = yspawn
                
        if player.room == "16":
        #Sets the screen boundaries for room 16 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.x < 25:
                player.x = 25
                player.lacc = 0.0
                player.lidle = 0.0
            if player.x > 675:
                player.x = 675
                player.racc = 0.0
                player.ridle = 0.0
            if player.y > 500:
                if answers[0] == "Terminal velocity.":
                    if 137.5 <= player.x <= 212.5:
                        room17()
                        player.y = 0
                        player.x = 25
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                    else:
                        room15()
                        player.y = 0
                        player.x = 337.5
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                if answers[1] == "Terminal velocity.":
                    if 312.5 <= player.x <= 387.5:
                        room17()
                        player.y = 0
                        player.x = 25
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                    else:
                        room15()
                        player.y = 0
                        player.x = 337.5
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                if answers[2] == "Terminal velocity.":
                    if 487.5 <= player.x <= 562.5:
                        room17()
                        player.y = 0
                        player.x = 25
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                    else:
                        room15()
                        player.y = 0
                        player.x = 337.5
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
            if player.x < 0 or player.x > 700 or player.y < 0 or (player.y > 500 and player.x < 137.5) or (player.y > 500 and player.x > 562.5):
                player.x = xspawn
                player.y = yspawn
                
        if player.room == "17":
        #Sets the screen boundaries for room 17 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.x < 25:
                player.x = 25
                player.lacc = 0.0
                player.lidle = 0.0
            if player.x > 675:
                player.x = 675
                player.racc = 0.0
                player.ridle = 0.0
            if player.y > 500:
                if answers[0] == "The force which pushes upwards against objects which are underwater.":
                    if 137.5 <= player.x <= 212.5:
                        room18()
                        player.y = 0
                        player.x = 25
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                    else:
                        room15()
                        player.y = 0
                        player.x = 337.5
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                if answers[1] == "The force which pushes upwards against objects which are underwater.":
                    if 312.5 <= player.x <= 387.5:
                        room18()
                        player.y = 0
                        player.x = 25
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                    else:
                        room15()
                        player.y = 0
                        player.x = 337.5
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                if answers[2] == "The force which pushes upwards against objects which are underwater.":
                    if 487.5 <= player.x <= 562.5:
                        room18()
                        player.y = 0
                        player.x = 25
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                    else:
                        room15()
                        player.y = 0
                        player.x = 337.5
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
            if player.x < 0 or player.x > 700 or player.y < 0 or (player.y > 500 and player.x < 137.5) or (player.y > 500 and player.x > 562.5):
                player.x = xspawn
                player.y = yspawn
        
        if player.room == "18":
        #Sets the screen boundaries for room 18 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.x < 25:
                player.x = 25
                player.lacc = 0.0
                player.lidle = 0.0
            if player.x > 675:
                player.x = 675
                player.racc = 0.0
                player.ridle = 0.0
            if player.y > 500:
                if answers[0] == "When two surfaces slide over each other.":
                    if 137.5 <= player.x <= 212.5:
                        room19()
                        player.y = 0
                        player.x = 25
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                    else:
                        room15()
                        player.y = 0
                        player.x = 337.5
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                if answers[1] == "When two surfaces slide over each other.":
                    if 312.5 <= player.x <= 387.5:
                        room19()
                        player.y = 0
                        player.x = 25
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                    else:
                        room15()
                        player.y = 0
                        player.x = 337.5
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                if answers[2] == "When two surfaces slide over each other.":
                    if 487.5 <= player.x <= 562.5:
                        room19()
                        player.y = 0
                        player.x = 25
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                    else:
                        room15()
                        player.y = 0
                        player.x = 337.5
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
            if player.x < 0 or player.x > 700 or player.y < 0 or (player.y > 500 and player.x < 137.5) or (player.y > 500 and player.x > 562.5):
                player.x = xspawn
                player.y = yspawn
                
        if player.room == "19":
            #Sets the screen boundaries for room 19 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.x < 25:
                player.x = 25
                player.lacc = 0.0
                player.lidle = 0.0
            if player.x > 675:
                player.x = 675
                player.racc = 0.0
                player.ridle = 0.0
            if player.y > 500:
                if answers[0] == "They will take more time to accelerate and decelerate.":
                    if 137.5 <= player.x <= 212.5:
                        room20()
                        player.y = 0
                        player.x = 25
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                    else:
                        room15()
                        player.y = 0
                        player.x = 337.5
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                if answers[1] == "They will take more time to accelerate and decelerate.":
                    if 312.5 <= player.x <= 387.5:
                        room20()
                        player.y = 0
                        player.x = 25
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                    else:
                        room15()
                        player.y = 0
                        player.x = 337.5
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                if answers[2] == "They will take more time to accelerate and decelerate.":
                    if 487.5 <= player.x <= 562.5:
                        room20()
                        player.y = 0
                        player.x = 25
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
                    else:
                        room15()
                        player.y = 0
                        player.x = 337.5
                        player.racc = 0.0
                        player.lacc = 0.0
                        player.ridle = 0.0
                        player.lidle = 0.0
            if player.x < 0 or player.x > 700 or player.y < 0 or (player.y > 500 and player.x < 137.5) or (player.y > 500 and player.x > 562.5):
                player.x = xspawn
                player.y = yspawn
            
        if player.room == "20":
        #Sets the screen boundaries for room 20 and what should happen when the player crosses them, along with the coordinates the player should move to when they come into contact with a hazard or fall off the screen in said room.
            if player.x < 25:
                player.x = 25
                player.lacc = 0.0
                player.lidle = 0.0
            if player.x > 675:
                player.x = 675
                player.racc = 0.0
                player.ridle = 0.0
            if player.y > 500:
                if answers[0] == "A type of friction.":
                    if 137.5 <= player.x <= 212.5:
                        minutes = int(time // 60)
                        seconds = time % 60
                        seconds = round(seconds, 1)
                        room21()    
                    else:
                        room15()
                if answers[1] == "A type of friction.":
                    if 312.5 <= player.x <= 387.5:
                        minutes = int(time // 60)
                        seconds = time % 60
                        seconds = round(seconds, 1)
                        room21()    
                    else:
                        room15()
                if answers[2] == "A type of friction.":
                    if 487.5 <= player.x <= 562.5:
                        minutes = int(time // 60)
                        seconds = time % 60
                        seconds = round(seconds, 1)
                        room21()
                    else:
                        room15()
                player.y = 0
                player.x = 337.5
                player.racc = 0.0
                player.lacc = 0.0
                player.ridle = 0.0
                player.lidle = 0.0
            if player.x < 0 or player.x > 700 or player.y < 0 or (player.y > 500 and player.x < 137.5) or (player.y > 500 and player.x > 562.5):
                player.x = xspawn
                player.y = yspawn
    
        clock.tick(60)
        
        if player.room != "title" or player.room != "21":
            if time < 5999:
                time = time + (1/60)
            else:
                time = 5999


main()
pygame.quit()
